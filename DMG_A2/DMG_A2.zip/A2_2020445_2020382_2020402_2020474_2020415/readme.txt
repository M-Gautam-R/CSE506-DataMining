To run the code , download the datasets given in the report and run the code cell that has all the read_csv()\

The first few cells are for preprocessing and for getting the TSNE plots ,run them all in order

Different sections have been marked for different algorithms, you need to run the metric scores for a given class of 
clustering algorithm immediately after the models have been trained on it, it is better to run all the cells under a given heading at once

Agglomerative Clustering requires manually changing the linkage type and changing the distance_threshold according to the dendrogram generated

